#include <string>
#include <fstream>
#include <iostream>
#include <algorithm>
#if defined(_WIN32)
    #include <windows.h>
#else
    #include <fts.h>
    #include <unistd.h>
    #include <stdlib.h>
    #include <limits.h>
    #include <dirent.h>
    #include <libgen.h>
    #include <sys/stat.h>
    #if defined(__APPLE__)
        #include <mach-o/dyld.h>
    #endif
#endif

using namespace std;

#if defined(_WIN32)
    typedef basic_string<WCHAR> tstring;
    tstring widen(string str)
    {
        const size_t wchar_count = str.size()+1;
        vector<WCHAR> buf(wchar_count);
        return tstring{buf.data(),(size_t)MultiByteToWideChar(CP_UTF8,0,str.c_str(),-1,buf.data(),wchar_count)};
    }

    string shorten(tstring str)
    {
        int nbytes = WideCharToMultiByte(CP_UTF8,0,str.c_str(),(int)str.length(),NULL,0,NULL,NULL);
        vector<char> buf((size_t)nbytes);
        return string{buf.data(),(size_t)WideCharToMultiByte(CP_UTF8,0,str.c_str(),(int)str.length(),buf.data(),nbytes,NULL,NULL)};
    }
#else
    struct dupslash
    {
        bool operator()(char a,char b) const
        {
            return (a == '/' && b == '/');
        }
    };
#endif

extern "C"
{
    double file_copy(char *fname,char *newname)
    {
        string str1(fname);
        string str2(newname);
        #if defined(_WIN32)
            replace(str1.begin(),str1.end(),'/','\\');
            replace(str2.begin(),str2.end(),'/','\\');
        #endif

        #if defined(_WIN32)
            WCHAR rpath1[MAX_PATH];
            WCHAR rpath2[MAX_PATH];
            GetFullPathNameW(widen(str1).c_str(),MAX_PATH,rpath1,NULL);
            GetFullPathNameW(widen(str2).c_str(),MAX_PATH,rpath2,NULL);
            str1 = string((char *)shorten(rpath1).c_str());
            str2 = string((char *)shorten(rpath2).c_str());
        #else
            str1.erase(unique(str1.begin(),str1.end(),dupslash()),str1.end());
            str2.erase(unique(str2.begin(),str2.end(),dupslash()),str2.end());
        #endif

        size_t slash1;
        size_t slash2;
        string dir1(str1);
        string dir2(str2);
        #if defined(_WIN32)
            if (dir1.find('\\') != string::npos)
                slash1 = dir1.find_last_of("\\");
            else
            {
                dir1 = string("");
                slash1 = 0;
            }

            if (dir2.find('\\') != string::npos)
                slash2 = dir2.find_last_of("\\");
            else
            {
                dir2 = string("");
                slash2 = 0;
            }
        #else
            if (dir1.find('/') != string::npos)
                slash1 = dir1.find_last_of("/");
            else
            {
                dir1 = string("");
                slash1 = 0;
            }

            if (dir2.find('/') != string::npos)
                slash2 = dir2.find_last_of("/");
            else
            {
                dir2 = string("");
                slash2 = 0;
            }
        #endif

        int proceed = (dir1.substr(0,slash1) != dir2.substr(0,slash2));

        #if !defined(_WIN32)
            string prestr1 = str1;
            string prestr2 = str2;

            string pardir1(dirname((char *)str1.c_str()));
            if (!pardir1.empty())
            {
                while (*pardir1.rbegin() == '/')
                {
                    pardir1.erase(pardir1.size()-1);
                }
            }
            struct stat pexist1;
            if (stat((char *)pardir1.c_str(),&pexist1) == 0 &&
                S_ISDIR(pexist1.st_mode))
            {
                char actpath1[PATH_MAX+1];
                char *ptr1 = realpath((char *)pardir1.c_str(),actpath1);
                if (ptr1 != NULL)
                {
                    string pardir2(dirname((char *)str2.c_str()));
                    if (!pardir2.empty())
                    {
                        while (*pardir2.rbegin() == '/')
                        {
                            pardir2.erase(pardir2.size()-1);
                        }
                    }
                    struct stat pexist2;
                    if (stat((char *)pardir2.c_str(),&pexist2) == 0 &&
                        S_ISDIR(pexist2.st_mode))
                    {
                        char actpath2[PATH_MAX+1];
                        char *ptr2 = realpath((char *)pardir2.c_str(),actpath2);
                        if (ptr2 != NULL)
                        {
                            proceed = (string(actpath1) != string(actpath2));
                        }
                    }
                }
            }

            str1 = prestr1;
            str2 = prestr2;
        #endif

        #if defined(_WIN32)
            tstring wstr1 = widen(str1);
            tstring wstr2 = widen(str2);

            size_t bn1 = str1.find_last_of("\\");
            size_t bn2 = str2.find_last_of("\\");

            if (proceed || (char *)str1.substr(bn1+1).c_str() != (char *)str2.substr(bn2+1).c_str())
            {
                DWORD attr = GetFileAttributesW(wstr1.c_str());
                if (attr != INVALID_FILE_ATTRIBUTES &&
                    (attr & ~FILE_ATTRIBUTE_DIRECTORY))
                {
                    return (CopyFileW(wstr1.c_str(),wstr2.c_str(),false) != 0);
                }
            }
        #else
            if (proceed || basename((char *)str1.c_str()) != basename((char *)str2.c_str()))
            {
                struct stat sb1;
                if (stat((char *)str1.c_str(),&sb1) == 0 &&
                    S_ISREG(sb1.st_mode))
                {
                    double ret = 0;
                    size_t sz1 = sb1.st_size;

                    ifstream srce((char *)str1.c_str(),ios::binary);
                    ret = (srce.tellg() >= 0);

                    ofstream dest((char *)str2.c_str(),ios::binary);
                    ret = (dest.tellp() >= 0);

                    dest << srce.rdbuf();
                    ret = (srce.tellg()-dest.tellp() == 0);

                    struct stat sb2;
                    if (stat((char *)str2.c_str(),&sb2) == 0 &&
                    S_ISREG(sb2.st_mode))
                    {
                        size_t sz2 = sb2.st_size;
                        return ((ret == 1) ||
                            (sz1 == 0 && sz2 == 0));
                    }
                }
            }
        #endif

        return 0;
    }

    double file_move(char *oldname,char *newname)
    {
        string str1(oldname);
        string str2(newname);
        #if defined(_WIN32)
            replace(str1.begin(),str1.end(),'/','\\');
            replace(str2.begin(),str2.end(),'/','\\');
        #endif

        #if defined(_WIN32)
            WCHAR rpath1[MAX_PATH];
            WCHAR rpath2[MAX_PATH];
            GetFullPathNameW(widen(str1).c_str(),MAX_PATH,rpath1,NULL);
            GetFullPathNameW(widen(str2).c_str(),MAX_PATH,rpath2,NULL);
            str1 = string((char *)shorten(rpath1).c_str());
            str2 = string((char *)shorten(rpath2).c_str());
        #else
            str1.erase(unique(str1.begin(),str1.end(),dupslash()),str1.end());
            str2.erase(unique(str2.begin(),str2.end(),dupslash()),str2.end());
        #endif

        size_t slash1;
        size_t slash2;
        string dir1(str1);
        string dir2(str2);
        #if defined(_WIN32)
            if (dir1.find('\\') != string::npos)
                slash1 = dir1.find_last_of("\\");
            else
            {
                dir1 = string("");
                slash1 = 0;
            }

            if (dir2.find('\\') != string::npos)
                slash2 = dir2.find_last_of("\\");
            else
            {
                dir2 = string("");
                slash2 = 0;
            }
        #else
            if (dir1.find('/') != string::npos)
                slash1 = dir1.find_last_of("/");
            else
            {
                dir1 = string("");
                slash1 = 0;
            }

            if (dir2.find('/') != string::npos)
                slash2 = dir2.find_last_of("/");
            else
            {
                dir2 = string("");
                slash2 = 0;
            }
        #endif

        int proceed = (dir1.substr(0,slash1) != dir2.substr(0,slash2));

        #if !defined(_WIN32)
            string prestr1 = str1;
            string prestr2 = str2;

            string pardir1(dirname((char *)str1.c_str()));
            if (!pardir1.empty())
            {
                while (*pardir1.rbegin() == '/')
                {
                    pardir1.erase(pardir1.size()-1);
                }
            }
            struct stat pexist1;
            if (stat((char *)pardir1.c_str(),&pexist1) == 0 &&
                S_ISDIR(pexist1.st_mode))
            {
                char actpath1[PATH_MAX+1];
                char *ptr1 = realpath((char *)pardir1.c_str(),actpath1);
                if (ptr1 != NULL)
                {
                    string pardir2(dirname((char *)str2.c_str()));
                    if (!pardir2.empty())
                    {
                        while (*pardir2.rbegin() == '/')
                        {
                            pardir2.erase(pardir2.size()-1);
                        }
                    }
                    struct stat pexist2;
                    if (stat((char *)pardir2.c_str(),&pexist2) == 0 &&
                        S_ISDIR(pexist2.st_mode))
                    {
                        char actpath2[PATH_MAX+1];
                        char *ptr2 = realpath((char *)pardir2.c_str(),actpath2);
                        if (ptr2 != NULL)
                        {
                            proceed = (string(actpath1) != string(actpath2));
                        }
                    }
                }
            }

            str1 = prestr1;
            str2 = prestr2;
        #endif

        #if defined(_WIN32)
            tstring wstr1 = widen(str1);
            tstring wstr2 = widen(str2);

            if (proceed)
            {
                DWORD attr1 = GetFileAttributesW(wstr1.c_str());
                DWORD attr2 = GetFileAttributesW(wstr2.c_str());
                if (attr1 != INVALID_FILE_ATTRIBUTES &&
                    (attr1 & ~FILE_ATTRIBUTE_DIRECTORY) &&
                    attr2 == INVALID_FILE_ATTRIBUTES)
                {
                    return (MoveFileW(wstr1.c_str(),wstr2.c_str()) != 0);
                }
            }
        #else
            if (proceed)
            {
                struct stat sb1;
                struct stat sb2;
                if (stat((char *)str1.c_str(),&sb1) == 0 &&
                    S_ISREG(sb1.st_mode) &&
                    stat((char *)str2.c_str(),&sb2) != 0)
                {
                    return (rename((char *)str1.c_str(),(char *)str2.c_str()) == 0);
                }
            }
        #endif

        return 0;
    }

    double file_rename(char *oldname,char *newname)
    {
        string str1(oldname);
        string str2(newname);
        #if defined(_WIN32)
            replace(str1.begin(),str1.end(),'/','\\');
            replace(str2.begin(),str2.end(),'/','\\');
        #endif

        #if defined(_WIN32)
            WCHAR rpath1[MAX_PATH];
            WCHAR rpath2[MAX_PATH];
            GetFullPathNameW(widen(str1).c_str(),MAX_PATH,rpath1,NULL);
            GetFullPathNameW(widen(str2).c_str(),MAX_PATH,rpath2,NULL);
            str1 = string((char *)shorten(rpath1).c_str());
            str2 = string((char *)shorten(rpath2).c_str());
        #else
            str1.erase(unique(str1.begin(),str1.end(),dupslash()),str1.end());
            str2.erase(unique(str2.begin(),str2.end(),dupslash()),str2.end());
        #endif

        size_t slash1;
        size_t slash2;
        string dir1(str1);
        string dir2(str2);
        #if defined(_WIN32)
            if (dir1.find('\\') != string::npos)
                slash1 = dir1.find_last_of("\\");
            else
            {
                dir1 = string("");
                slash1 = 0;
            }

            if (dir2.find('\\') != string::npos)
                slash2 = dir2.find_last_of("\\");
            else
            {
                dir2 = string("");
                slash2 = 0;
            }
        #else
            if (dir1.find('/') != string::npos)
                slash1 = dir1.find_last_of("/");
            else
            {
                dir1 = string("");
                slash1 = 0;
            }

            if (dir2.find('/') != string::npos)
                slash2 = dir2.find_last_of("/");
            else
            {
                dir2 = string("");
                slash2 = 0;
            }
        #endif

        int proceed = (dir1.substr(0,slash1) == dir2.substr(0,slash2));

        #if !defined(_WIN32)
            string prestr1 = str1;
            string prestr2 = str2;

            string pardir1(dirname((char *)str1.c_str()));
            if (!pardir1.empty())
            {
                while (*pardir1.rbegin() == '/')
                {
                    pardir1.erase(pardir1.size()-1);
                }
            }
            struct stat pexist1;
            if (stat((char *)pardir1.c_str(),&pexist1) == 0 &&
                S_ISDIR(pexist1.st_mode))
            {
                char actpath1[PATH_MAX+1];
                char *ptr1 = realpath((char *)pardir1.c_str(),actpath1);
                if (ptr1 != NULL)
                {
                    string pardir2(dirname((char *)str2.c_str()));
                    if (!pardir2.empty())
                    {
                        while (*pardir2.rbegin() == '/')
                        {
                            pardir2.erase(pardir2.size()-1);
                        }
                    }
                    struct stat pexist2;
                    if (stat((char *)pardir2.c_str(),&pexist2) == 0 &&
                        S_ISDIR(pexist2.st_mode))
                    {
                        char actpath2[PATH_MAX+1];
                        char *ptr2 = realpath((char *)pardir2.c_str(),actpath2);
                        if (ptr2 != NULL)
                        {
                            proceed = (string(actpath1) == string(actpath2));
                        }
                    }
                }
            }

            str1 = prestr1;
            str2 = prestr2;
        #endif

        #if defined(_WIN32)
            tstring wstr1 = widen(str1);
            tstring wstr2 = widen(str2);

            size_t bn1 = str1.find_last_of("\\");
            size_t bn2 = str2.find_last_of("\\");

            if (proceed && (char *)str1.substr(bn1+1).c_str() != (char *)str2.substr(bn2+1).c_str())
            {
                DWORD attr1 = GetFileAttributesW(wstr1.c_str());
                DWORD attr2 = GetFileAttributesW(wstr2.c_str());
                if (attr1 != INVALID_FILE_ATTRIBUTES &&
                    (attr1 & ~FILE_ATTRIBUTE_DIRECTORY) &&
                    attr2 == INVALID_FILE_ATTRIBUTES)
                {
                    return (MoveFileW(wstr1.c_str(),wstr2.c_str()) != 0);
                }
            }
        #else
            if (proceed && basename((char *)str1.c_str()) != basename((char *)str2.c_str()))
            {
                struct stat sb1;
                struct stat sb2;
                if (stat((char *)str1.c_str(),&sb1) == 0 &&
                    S_ISREG(sb1.st_mode) &&
                    stat((char *)str2.c_str(),&sb2) != 0)
                {
                    return (rename((char *)str1.c_str(),(char *)str2.c_str()) == 0);
                }
            }
        #endif

        return 0;
    }

    double file_exists(char *fname)
    {
        string str(fname);
        #if defined(_WIN32)
            replace(str.begin(),str.end(),'/','\\');
        #endif

        #if defined(_WIN32)
            tstring wstr = widen(str);

            DWORD attr = GetFileAttributesW(wstr.c_str());
            return (attr != INVALID_FILE_ATTRIBUTES &&
                (attr & ~FILE_ATTRIBUTE_DIRECTORY));
        #else
            struct stat sb;
            return (stat((char *)str.c_str(),&sb) == 0 &&
                S_ISREG(sb.st_mode));
        #endif
    }

    double file_delete(char *fname)
    {
        string str(fname);
        #if defined(_WIN32)
            replace(str.begin(),str.end(),'/','\\');
        #endif

        #if defined(_WIN32)
            tstring wstr = widen(str);

            DWORD attr = GetFileAttributesW(wstr.c_str());
            if (attr != INVALID_FILE_ATTRIBUTES &&
                (attr & ~FILE_ATTRIBUTE_DIRECTORY))
            {
                return (DeleteFileW(wstr.c_str()) != 0);
            }
        #else
            struct stat sb;
            if (stat((char *)str.c_str(),&sb) == 0 &&
                S_ISREG(sb.st_mode))
            {
                return (remove((char *)str.c_str()) == 0);
            }
        #endif

        return 0;
    }

    double directory_create(char *dname)
    {
        string str(dname);
        #if defined(_WIN32)
            replace(str.begin(),str.end(),'/','\\');
        #endif

        if (!str.empty())
        {
            #if defined(_WIN32)
                while (*str.rbegin() == '\\')
                {
                    str.erase(str.size()-1);
                }
            #else
                while (*str.rbegin() == '/')
                {
                    str.erase(str.size()-1);
                }
            #endif
        }

        #if defined(_WIN32)
            tstring wstr = widen(str);

            DWORD attr = GetFileAttributesW(wstr.c_str());
            if (attr == INVALID_FILE_ATTRIBUTES)
            {
                return (CreateDirectoryW(wstr.c_str(),NULL) != 0);
            }
        #else
            struct stat sb;
            if (stat((char *)str.c_str(),&sb) != 0)
            {
                return (mkdir((char *)str.c_str(),0777) == 0);
            }
        #endif

        return 0;
    }

    double directory_copy(char *dname,char *newname)
    {
        string str1(dname);
        string str2(newname);
        #if defined(_WIN32)
            replace(str1.begin(),str1.end(),'/','\\');
            replace(str2.begin(),str2.end(),'/','\\');
        #endif

        #if defined(_WIN32)
            WCHAR rpath1[MAX_PATH];
            WCHAR rpath2[MAX_PATH];
            GetFullPathNameW(widen(str1).c_str(),MAX_PATH,rpath1,NULL);
            GetFullPathNameW(widen(str2).c_str(),MAX_PATH,rpath2,NULL);
            str1 = string((char *)shorten(rpath1).c_str());
            str2 = string((char *)shorten(rpath2).c_str());
        #else
            str1.erase(unique(str1.begin(),str1.end(),dupslash()),str1.end());
            str2.erase(unique(str2.begin(),str2.end(),dupslash()),str2.end());
        #endif

        if (!str1.empty())
        {
            #if defined(_WIN32)
                while (*str1.rbegin() == '\\')
                {
                    str1.erase(str1.size()-1);
                }
            #else
                while (*str1.rbegin() == '/')
                {
                    str1.erase(str1.size()-1);
                }
            #endif
        }
        if (!str2.empty())
        {
            #if defined(_WIN32)
                while (*str2.rbegin() == '\\')
                {
                    str2.erase(str2.size()-1);
                }
            #else
                while (*str2.rbegin() == '/')
                {
                    str2.erase(str2.size()-1);
                }
            #endif
        }

        size_t slash1;
        size_t slash2;
        string dir1(str1);
        string dir2(str2);
        #if defined(_WIN32)
            if (dir1.find('\\') != string::npos)
                slash1 = dir1.find_last_of("\\");
            else
            {
                dir1 = string("");
                slash1 = 0;
            }

            if (dir2.find('\\') != string::npos)
                slash2 = dir2.find_last_of("\\");
            else
            {
                dir2 = string("");
                slash2 = 0;
            }
        #else
            if (dir1.find('/') != string::npos)
                slash1 = dir1.find_last_of("/");
            else
            {
                dir1 = string("");
                slash1 = 0;
            }

            if (dir2.find('/') != string::npos)
                slash2 = dir2.find_last_of("/");
            else
            {
                dir2 = string("");
                slash2 = 0;
            }
        #endif

        int proceed1 = (str1 != str2.substr(0,str1.length()));
        int proceed2 = (dir1.substr(0,slash1) == dir2.substr(0,slash2));

        #if !defined(_WIN32)
            string prestr1 = str1;
            string prestr2 = str2;
            string poststr1 = str1;
            string poststr2 = str2;

            string pardir1(dirname((char *)str1.c_str()));
            if (!pardir1.empty())
            {
                while (*pardir1.rbegin() == '/')
                {
                    pardir1.erase(pardir1.size()-1);
                }
            }
            struct stat pexist1;
            if (stat((char *)pardir1.c_str(),&pexist1) == 0 &&
                S_ISDIR(pexist1.st_mode))
            {
                char actpath1[PATH_MAX+1];
                char *ptr1 = realpath((char *)pardir1.c_str(),actpath1);
                if (ptr1 != NULL)
                {
                    string pardir2(dirname((char *)str2.c_str()));
                    if (!pardir2.empty())
                    {
                        while (*pardir2.rbegin() == '/')
                        {
                            pardir2.erase(pardir2.size()-1);
                        }
                    }
                    struct stat pexist2;
                    if (stat((char *)pardir2.c_str(),&pexist2) == 0 &&
                        S_ISDIR(pexist2.st_mode))
                    {
                        char actpath2[PATH_MAX+1];
                        char *ptr2 = realpath((char *)pardir2.c_str(),actpath2);
                        if (ptr2 != NULL)
                        {
                            string parbas1(string("/")+basename((char *)poststr1.c_str()));
                            string parbas2(string("/")+basename((char *)poststr2.c_str()));

                            proceed1 = (string(actpath1+parbas1) != string(actpath2+parbas2).substr(0,string(actpath1+parbas1).length()));
                            proceed2 = (string(actpath1) == string(actpath2));
                        }
                    }
                }
            }

            str1 = prestr1;
            str2 = prestr2;
        #endif

        #if defined(_WIN32)
            tstring wstr1 = widen(str1);
            tstring wstr2 = widen(str2);

            size_t bn1 = str1.find_last_of("\\");
            size_t bn2 = str2.find_last_of("\\");

            if (proceed1 || (proceed2 && (char *)str1.substr(bn1+1).c_str() != (char *)str2.substr(bn2+1).c_str()))
            {
                DWORD attr1 = GetFileAttributesW(wstr1.c_str());
                DWORD attr2 = GetFileAttributesW(wstr2.c_str());
                if (attr1 != INVALID_FILE_ATTRIBUTES &&
                    (attr1 & FILE_ATTRIBUTE_DIRECTORY) &&
                    attr2 == INVALID_FILE_ATTRIBUTES)
                {
                    tstring strSource;
                    tstring strDestination;
                    tstring strPattern;

                    HANDLE hFile;
                    WIN32_FIND_DATAW FileInformation;

                    strPattern = widen(str1+"\\*.*");

                    if (!directory_create((char *)shorten(wstr2).c_str()))
                        return 0;

                    hFile = FindFirstFileW(strPattern.c_str(),&FileInformation);
                    if (hFile != INVALID_HANDLE_VALUE)
                    {
                        do
                        {
                            if (FileInformation.cFileName[0] != '.')
                            {
                                strSource.erase();
                                strDestination.erase();

                                strSource = widen(str1+"\\"+shorten(FileInformation.cFileName));
                                strDestination = widen(str2+"\\"+shorten(FileInformation.cFileName));

                                if (FileInformation.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                                {
                                    if (!directory_copy((char *)shorten(strSource).c_str(),(char *)shorten(strDestination).c_str()))
                                        return 0;
                                }
                                else
                                {
                                    if (!file_copy((char *)shorten(strSource).c_str(),(char *)shorten(strDestination).c_str()))
                                        return 0;
                                }
                            }
                        }
                        while (FindNextFileW(hFile,&FileInformation));

                        FindClose(hFile);

                        DWORD dwError = GetLastError();
                        if (dwError != ERROR_NO_MORE_FILES)
                            return 0;
                    }

                    return 1;
                }
            }
        #else
            if (proceed1 || (proceed2 && basename((char *)str1.c_str()) != basename((char *)str2.c_str())))
            {
                struct stat sb1;
                struct stat sb2;
                if (stat((char *)str1.c_str(),&sb1) == 0 &&
                    S_ISDIR(sb1.st_mode) &&
                    stat((char *)str2.c_str(),&sb2) != 0)
                {
                    if (!directory_create((char *)str2.c_str()))
                        return 0;

                    DIR *dir;
                    struct dirent *ent;
                    if ((dir = opendir((char *)str1.c_str())) != NULL)
                    {
                        while ((ent = readdir(dir)) != NULL)
                        {
                            if (ent->d_name != string("."))
                            {
                                if (ent->d_name != string(".."))
                                {
                                    string copy_sorc = str1+"/"+ent->d_name;
                                    string copy_dest = str2+"/"+ent->d_name;

                                    struct stat sb3;
                                    if (stat((char *)copy_sorc.c_str(),&sb3) == 0 &&
                                    S_ISDIR(sb3.st_mode))
                                    {
                                        if (!directory_copy((char *)copy_sorc.c_str(),(char *)copy_dest.c_str()))
                                            return 0;
                                    }

                                    struct stat sb4;
                                    if (stat((char *)copy_sorc.c_str(),&sb4) == 0 &&
                                        S_ISREG(sb4.st_mode))
                                    {
                                        if (!file_copy((char *)copy_sorc.c_str(),(char *)copy_dest.c_str()))
                                            return 0;
                                    }
                                }
                            }
                        }

                        closedir(dir);
                    }
                    else
                    {
                        return 0;
                    }

                    return 1;
                }
            }
        #endif

        return 0;
    }

    double directory_move(char *oldname,char *newname)
    {
        string str1(oldname);
        string str2(newname);
        #if defined(_WIN32)
            replace(str1.begin(),str1.end(),'/','\\');
            replace(str2.begin(),str2.end(),'/','\\');
        #endif

        #if defined(_WIN32)
            WCHAR rpath1[MAX_PATH];
            WCHAR rpath2[MAX_PATH];
            GetFullPathNameW(widen(str1).c_str(),MAX_PATH,rpath1,NULL);
            GetFullPathNameW(widen(str2).c_str(),MAX_PATH,rpath2,NULL);
            str1 = string((char *)shorten(rpath1).c_str());
            str2 = string((char *)shorten(rpath2).c_str());
        #else
            str1.erase(unique(str1.begin(),str1.end(),dupslash()),str1.end());
            str2.erase(unique(str2.begin(),str2.end(),dupslash()),str2.end());
        #endif

        if (!str1.empty())
        {
            #if defined(_WIN32)
                while (*str1.rbegin() == '\\')
                {
                    str1.erase(str1.size()-1);
                }
            #else
                while (*str1.rbegin() == '/')
                {
                    str1.erase(str1.size()-1);
                }
            #endif
        }
        if (!str2.empty())
        {
            #if defined(_WIN32)
                while (*str2.rbegin() == '\\')
                {
                    str2.erase(str2.size()-1);
                }
            #else
                while (*str2.rbegin() == '/')
                {
                    str2.erase(str2.size()-1);
                }
            #endif
        }

        size_t slash1;
        size_t slash2;
        string dir1(str1);
        string dir2(str2);
        #if defined(_WIN32)
            if (dir1.find('\\') != string::npos)
                slash1 = dir1.find_last_of("\\");
            else
            {
                dir1 = string("");
                slash1 = 0;
            }

            if (dir2.find('\\') != string::npos)
                slash2 = dir2.find_last_of("\\");
            else
            {
                dir2 = string("");
                slash2 = 0;
            }
        #else
            if (dir1.find('/') != string::npos)
                slash1 = dir1.find_last_of("/");
            else
            {
                dir1 = string("");
                slash1 = 0;
            }

            if (dir2.find('/') != string::npos)
                slash2 = dir2.find_last_of("/");
            else
            {
                dir2 = string("");
                slash2 = 0;
            }
        #endif

        int proceed1 = (str1 != str2.substr(0,str1.length()));
        int proceed2 = (dir1.substr(0,slash1) != dir2.substr(0,slash2));

        #if !defined(_WIN32)
            string prestr1 = str1;
            string prestr2 = str2;
            string poststr1 = str1;
            string poststr2 = str2;

            string pardir1(dirname((char *)str1.c_str()));
            if (!pardir1.empty())
            {
                while (*pardir1.rbegin() == '/')
                {
                    pardir1.erase(pardir1.size()-1);
                }
            }
            struct stat pexist1;
            if (stat((char *)pardir1.c_str(),&pexist1) == 0 &&
                S_ISDIR(pexist1.st_mode))
            {
                char actpath1[PATH_MAX+1];
                char *ptr1 = realpath((char *)pardir1.c_str(),actpath1);
                if (ptr1 != NULL)
                {
                    string pardir2(dirname((char *)str2.c_str()));
                    if (!pardir2.empty())
                    {
                        while (*pardir2.rbegin() == '/')
                        {
                            pardir2.erase(pardir2.size()-1);
                        }
                    }
                    struct stat pexist2;
                    if (stat((char *)pardir2.c_str(),&pexist2) == 0 &&
                        S_ISDIR(pexist2.st_mode))
                    {
                        char actpath2[PATH_MAX+1];
                        char *ptr2 = realpath((char *)pardir2.c_str(),actpath2);
                        if (ptr2 != NULL)
                        {
                            string parbas1(string("/")+basename((char *)poststr1.c_str()));
                            string parbas2(string("/")+basename((char *)poststr2.c_str()));

                            proceed1 = (string(actpath1+parbas1) != string(actpath2+parbas2).substr(0,string(actpath1+parbas1).length()));
                            proceed2 = (string(actpath1) != string(actpath2));
                        }
                    }
                }
            }

            str1 = prestr1;
            str2 = prestr2;
        #endif

        #if defined(_WIN32)
            tstring wstr1 = widen(str1);
            tstring wstr2 = widen(str2);

            if (proceed1 && proceed2)
            {
                DWORD attr1 = GetFileAttributesW(wstr1.c_str());
                DWORD attr2 = GetFileAttributesW(wstr2.c_str());
                if (attr1 != INVALID_FILE_ATTRIBUTES &&
                    (attr1 & FILE_ATTRIBUTE_DIRECTORY) &&
                    attr2 == INVALID_FILE_ATTRIBUTES)
                {
                    return (MoveFileW(wstr1.c_str(),wstr2.c_str()) != 0);
                }
            }
        #else
            if (proceed1 && proceed2)
            {
                struct stat sb1;
                struct stat sb2;
                if (stat((char *)str1.c_str(),&sb1) == 0 &&
                    S_ISDIR(sb1.st_mode) &&
                    stat((char *)str2.c_str(),&sb2) != 0)
                {
                    return (rename((char *)str1.c_str(),(char *)str2.c_str()) == 0);
                }
            }
        #endif

        return 0;
    }

    double directory_rename(char *oldname,char *newname)
    {
        string str1(oldname);
        string str2(newname);
        #if defined(_WIN32)
            replace(str1.begin(),str1.end(),'/','\\');
            replace(str2.begin(),str2.end(),'/','\\');
        #endif

        #if defined(_WIN32)
            WCHAR rpath1[MAX_PATH];
            WCHAR rpath2[MAX_PATH];
            GetFullPathNameW(widen(str1).c_str(),MAX_PATH,rpath1,NULL);
            GetFullPathNameW(widen(str2).c_str(),MAX_PATH,rpath2,NULL);
            str1 = string((char *)shorten(rpath1).c_str());
            str2 = string((char *)shorten(rpath2).c_str());
        #else
            str1.erase(unique(str1.begin(),str1.end(),dupslash()),str1.end());
            str2.erase(unique(str2.begin(),str2.end(),dupslash()),str2.end());
        #endif

        if (!str1.empty())
        {
            #if defined(_WIN32)
                while (*str1.rbegin() == '\\')
                {
                    str1.erase(str1.size()-1);
                }
            #else
                while (*str1.rbegin() == '/')
                {
                    str1.erase(str1.size()-1);
                }
            #endif
        }
        if (!str2.empty())
        {
            #if defined(_WIN32)
                while (*str2.rbegin() == '\\')
                {
                    str2.erase(str2.size()-1);
                }
            #else
                while (*str2.rbegin() == '/')
                {
                    str2.erase(str2.size()-1);
                }
            #endif
        }

        size_t slash1;
        size_t slash2;
        string dir1(str1);
        string dir2(str2);
        #if defined(_WIN32)
            if (dir1.find('\\') != string::npos)
                slash1 = dir1.find_last_of("\\");
            else
            {
                dir1 = string("");
                slash1 = 0;
            }

            if (dir2.find('\\') != string::npos)
                slash2 = dir2.find_last_of("\\");
            else
            {
                dir2 = string("");
                slash2 = 0;
            }
        #else
            if (dir1.find('/') != string::npos)
                slash1 = dir1.find_last_of("/");
            else
            {
                dir1 = string("");
                slash1 = 0;
            }

            if (dir2.find('/') != string::npos)
                slash2 = dir2.find_last_of("/");
            else
            {
                dir2 = string("");
                slash2 = 0;
            }
        #endif

        int proceed = (dir1.substr(0,slash1) == dir2.substr(0,slash2));

        #if !defined(_WIN32)
            string prestr1 = str1;
            string prestr2 = str2;

            string pardir1(dirname((char *)str1.c_str()));
            if (!pardir1.empty())
            {
                while (*pardir1.rbegin() == '/')
                {
                    pardir1.erase(pardir1.size()-1);
                }
            }
            struct stat pexist1;
            if (stat((char *)pardir1.c_str(),&pexist1) == 0 &&
                S_ISDIR(pexist1.st_mode))
            {
                char actpath1[PATH_MAX+1];
                char *ptr1 = realpath((char *)pardir1.c_str(),actpath1);
                if (ptr1 != NULL)
                {
                    string pardir2(dirname((char *)str2.c_str()));
                    if (!pardir2.empty())
                    {
                        while (*pardir2.rbegin() == '/')
                        {
                            pardir2.erase(pardir2.size()-1);
                        }
                    }
                    struct stat pexist2;
                    if (stat((char *)pardir2.c_str(),&pexist2) == 0 &&
                        S_ISDIR(pexist2.st_mode))
                    {
                        char actpath2[PATH_MAX+1];
                        char *ptr2 = realpath((char *)pardir2.c_str(),actpath2);
                        if (ptr2 != NULL)
                        {
                            proceed = (string(actpath1) == string(actpath2));
                        }
                    }
                }
            }

            str1 = prestr1;
            str2 = prestr2;
        #endif

        #if defined(_WIN32)
            tstring wstr1 = widen(str1);
            tstring wstr2 = widen(str2);

            size_t bn1 = str1.find_last_of("\\");
            size_t bn2 = str2.find_last_of("\\");

            if (proceed && (char *)str1.substr(bn1+1).c_str() != (char *)str2.substr(bn2+1).c_str())
            {
                DWORD attr1 = GetFileAttributesW(wstr1.c_str());
                DWORD attr2 = GetFileAttributesW(wstr2.c_str());
                if (attr1 != INVALID_FILE_ATTRIBUTES &&
                    (attr1 & FILE_ATTRIBUTE_DIRECTORY) &&
                    attr2 == INVALID_FILE_ATTRIBUTES)
                {
                    return (MoveFileW(wstr1.c_str(),wstr2.c_str()) != 0);
                }
            }
        #else
            if (proceed && basename((char *)str1.c_str()) != basename((char *)str2.c_str()))
            {
                struct stat sb1;
                struct stat sb2;
                if (stat((char *)str1.c_str(),&sb1) == 0 &&
                    S_ISDIR(sb1.st_mode) &&
                    stat((char *)str2.c_str(),&sb2) != 0)
                {
                    return (rename((char *)str1.c_str(),(char *)str2.c_str()) == 0);
                }
            }
        #endif

        return 0;
    }

    double directory_exists(char *dname)
    {
        string str(dname);
        #if defined(_WIN32)
            replace(str.begin(),str.end(),'/','\\');
        #endif

        if (!str.empty())
        {
            #if defined(_WIN32)
                while (*str.rbegin() == '\\')
                {
                    str.erase(str.size()-1);
                }
            #else
                while (*str.rbegin() == '/')
                {
                    str.erase(str.size()-1);
                }
            #endif
        }

        #if defined(_WIN32)
            tstring wstr = widen(str);

            DWORD attr = GetFileAttributesW(wstr.c_str());
            return (attr != INVALID_FILE_ATTRIBUTES &&
                (attr & FILE_ATTRIBUTE_DIRECTORY));
        #else
            struct stat sb;
            return (stat((char *)str.c_str(),&sb) == 0 &&
                S_ISDIR(sb.st_mode));
        #endif
    }

    double directory_delete(char *dname)
    {
        string str(dname);
        #if defined(_WIN32)
            replace(str.begin(),str.end(),'/','\\');
        #endif

        #if defined(_WIN32)
            WCHAR rpath[MAX_PATH];
            GetFullPathNameW(widen(str).c_str(),MAX_PATH,rpath,NULL);
            str = string((char *)shorten(rpath).c_str());
        #endif

        if (!str.empty())
        {
            #if defined(_WIN32)
                while (*str.rbegin() == '\\')
                {
                    str.erase(str.size()-1);
                }
            #else
                while (*str.rbegin() == '/')
                {
                    str.erase(str.size()-1);
                }
            #endif
        }

        #if defined(_WIN32)
            tstring wstr = widen(str);

            DWORD attr = GetFileAttributesW(wstr.c_str());
            if (attr != INVALID_FILE_ATTRIBUTES &&
                (attr & FILE_ATTRIBUTE_DIRECTORY))
            {
                SHFILEOPSTRUCTW fileop = {0};

                fileop.hwnd = NULL;
                fileop.wFunc = FO_DELETE;
                fileop.pFrom = wstr.c_str();
                fileop.fFlags = FOF_NOCONFIRMATION|FOF_NOERRORUI|FOF_SILENT;

                return (SHFileOperationW(&fileop) == 0);
            }
        #else
            struct stat sb;
            if (stat((char *)str.c_str(),&sb) == 0 &&
                S_ISDIR(sb.st_mode))
            {
                FTS *ftsp = NULL;
                FTSENT *curr;

                char *files[] = {(char *)str.c_str(),NULL};
                ftsp = fts_open(files,FTS_NOCHDIR|FTS_PHYSICAL|FTS_XDEV,NULL);
                if (!ftsp)
                {
                    return 0;
                    goto finish;
                }

                while ((curr = fts_read(ftsp)))
                {
                    switch (curr->fts_info)
                    {
                        case FTS_NS:
                        case FTS_DNR:
                        case FTS_ERR:
                            return 0;
                            break;

                        case FTS_DC:
                        case FTS_DOT:
                        case FTS_NSOK:
                            break;

                        case FTS_D:
                            break;

                        case FTS_DP:
                        case FTS_F:
                        case FTS_SL:
                        case FTS_SLNONE:
                        case FTS_DEFAULT:
                            if (remove(curr->fts_accpath) < 0)
                            {
                                return 0;
                            }
                            break;
                    }
                }

                finish:
                    if (ftsp)
                    {
                        fts_close(ftsp);
                    }

                return 1;
            }
        #endif

        return 0;
    }

    char *program_directory()
    {
        #if defined(_WIN32)
            WCHAR result[MAX_PATH];
            GetModuleFileNameW(NULL,result,MAX_PATH);
            string::size_type pos = string((char *)shorten(result).c_str()).find_last_of("\\");
            if (pos != string::npos)
            {
                return (char *)string(string((char *)shorten(result).c_str()).substr(0,pos)+string("\\")).c_str();
            }
        #endif
        #if defined(__APPLE__)
            char result[PATH_MAX];
            uint32_t size = sizeof(result);
            if (_NSGetExecutablePath(result,&size) == 0)
            {
                string str(dirname(result));
                return (char *)string(str+string("/")).c_str();
            }
        #endif
        #if defined(linux)
            char result[PATH_MAX];
            ssize_t count = readlink("/proc/self/exe",result,PATH_MAX);
            if (count != -1)
            {
                string str(dirname(result));
                return (char *)string(str+string("/")).c_str();
            }
        #endif

        return (char *)"";
    }
}
